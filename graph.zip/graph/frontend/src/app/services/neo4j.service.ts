import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Neo4jService {

  private baseUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  // (a) citation check
  checkCitation(paperA: string, paperB: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/cite-check`, {
      params: { paperA, paperB }
    });
  }

  // (b) classification
  getClassification(id: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/classification`, {
      params: { id }
    });
  }

  // (c) custom query
  customQuery(query: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/query`, {
      query
    });
  }
}