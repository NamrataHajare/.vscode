import { Component } from '@angular/core';
import { Neo4jService } from '../../services/neo4j.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChangeDetectorRef } from '@angular/core'; 

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search.html',
  styleUrls: ['./search.css']
})
export class SearchComponent {

  queryType: string = 'cite';
  paperA: string = '';
  paperB: string = '';
  paper: string = '';
  customQuery: string = '';

  result: any;
  loading = false;

  output : any[] = [];

  constructor(private neo4jService: Neo4jService , private cdr : ChangeDetectorRef) {}

  // Add these inside your SearchComponent class
getObjectKeys(obj: any): string[] {
  return obj ? Object.keys(obj) : [];
}

formatValue(val: any): string {
  // Neo4j integers often come back as objects {low: x, high: y}
  if (val && typeof val === 'object' && 'low' in val) {
    return val.low.toString();
  }
  return val;
}
  search() {
    this.loading = true;
    this.result = null;

    if (this.queryType === 'cite') {
      this.loading = true;
  
  // Explicitly wrap in String() to ensure Neo4j receives the correct type
  const idA = String(this.paperA);
  const idB = String(this.paperB);

  this.neo4jService.checkCitation(idA, idB)
    .subscribe({
      next: (res) => {
        this.result = res;
        console.log(res);
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Query error:', err);
        this.loading = false;
        this.result = { error: 'Query failed.' };
      }
    });

    } 
    else if (this.queryType === 'class') {
      this.neo4jService.getClassification(this.paper)
        .subscribe({
          next: (res) => {
            this.result = res;
            this.loading = false;
            console.log(this.result);
            this.cdr.detectChanges();
          },
          error: (err) => {
            console.error('Query error:', err);
            this.loading = false;
            this.result = { error: 'Query failed. Check console.' };
          }
        });

    } 
    else {
      this.neo4jService.customQuery(this.customQuery)
        .subscribe({
          next: (res) => {
            this.output = res?.result || res || [];
            console.log(this.output);
            this.loading = false;
            this.cdr.detectChanges();
          },
          error: (err) => {
            console.error('Query error:', err);
            this.loading = false;
             this.output = [];   // ✅ FIX: keep consistent state
             this.cdr.detectChanges();
            this.result = { error: 'Query failed. Check console.' };
          }
        });
    }
  }
}
