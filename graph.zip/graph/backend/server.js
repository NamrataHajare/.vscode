const express = require('express');
const neo4j = require('neo4j-driver');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const driver = neo4j.driver(
  'neo4j://localhost:7687',
  neo4j.auth.basic('neo4j', 'Neo4j0032') 
);

console.log('Neo4j driver initialized');

const getSession = () => driver.session();

app.get('/api/cite-check', async (req, res) => {
  const { paperA, paperB } = req.query;
  console.log("enter");
  if (!paperA || !paperB) {
    return res.status(400).json({ error: 'Missing paper A or B' });
  }

  const session = getSession();

  try {
    const result = await session.run(
      `
     MATCH path = shortestPath(
  (a:Paper {id: $paperA})-[:CITES*]-(b:Paper {id: $paperB})
)
RETURN path;
      `,
      { paperA, paperB }
    );
    console.log(result);
    if (result.records.length > 0) {
      const path = result.records[0].get('path');

      const formattedPath = path.segments.map(seg => ({
        from: seg.start.properties,
        relation: seg.relationship.type,
        to: seg.end.properties
      }));

      res.json({
        cites: true,
        length: path.length,
        path: formattedPath
      });
    } else {
      res.json({ cites: false });
    }

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Query failed' });
  } finally {
    await session.close();
  }
});


app.get('/api/classification', async (req, res) => {
  const { id } = req.query;

  if (!id) {
    return res.status(400).json({ error: 'Missing paper id' });
  }

  const session = getSession();

  try {
    const result = await session.run(
      `
      MATCH (p:Paper {id: $id})
      RETURN p.id AS id,
             p.title AS title,
             p.category AS category
      `,
      { id }
    );

    if (result.records.length === 0) {
      return res.status(404).json({ error: 'Paper not found' });
    }

    const record = result.records[0];

    res.json({
      id: record.get('id'),
      title: record.get('title'),
      category: record.get('category') || null
    });

  } catch (err) {
    console.error('Classification error:', err);
    res.status(500).json({ error: err.message });
  } finally {
    await session.close();
  }
});


app.get('/search', async (req, res) => {
  const { id } = req.query;

  if (!id) {
    return res.status(400).json({ error: 'Missing paper ID' });
  }

  const session = getSession();

  try {
    const result = await session.run(
      `
      MATCH (p:Paper {id: $id})
      OPTIONAL MATCH (p)-[:AUTHORED_BY]->(a:Author)
      RETURN p, collect(a.name) AS authors
      `,
      { id }
    );

    if (result.records.length > 0) {
      const record = result.records[0];

      res.json({
        paper: record.get('p').properties,
        authors: record.get('authors')
      });

    } else {
      res.status(404).json({ error: 'Paper not found' });
    }

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Query failed' });
  } finally {
    await session.close();
  }
});

app.post('/api/query', async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Missing Cypher query' });
  }

  const session = getSession();

  try {
    const result = await session.run(query);

    const data = result.records.map(record => {
      const obj = {};
      record.keys.forEach(key => {
        const value = record.get(key);

        obj[key] =
          value && value.properties ? value.properties :
            value;
      });
      return obj;
    });

    res.json({
      result: data
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({
      error: 'Query failed',
      details: err.message
    });
  } finally {
    await session.close();
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});