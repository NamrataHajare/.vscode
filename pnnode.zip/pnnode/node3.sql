
CREATE EXTENSION IF NOT EXISTS postgres_fdw;

-- Connect to Node1 (portal_db)
CREATE SERVER node2_server
FOREIGN DATA WRAPPER postgres_fdw
OPTIONS (host '127.0.0.1', port '5433', dbname 'academic_db');

CREATE USER MAPPING FOR node3
SERVER node2_server
OPTIONS (user 'node2', password '6789');

IMPORT FOREIGN SCHEMA public 
FROM SERVER node2_server 
INTO public;

DROP FOREIGN TABLE users;
DROP FOREIGN TABLE staff_profiles;
DROP FOREIGN TABLE student_profiles;

DROP USER MAPPING FOR node3 SERVER node1_server;

DROP SERVER node1_server CASCADE;

CREATE TABLE exams (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    start_time TIMESTAMP,
    duration_minutes INT,
    course_id INT ,
    is_active BOOLEAN DEFAULT true
);
select * fr
CREATE TABLE exam_attempts (
    id SERIAL PRIMARY KEY,
    student_id INT ,
    exam_id INT REFERENCES exams(id),
    status VARCHAR(20) DEFAULT 'available',
    score DECIMAL(5,2),
    start_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    end_timestamp TIMESTAMP
);

CREATE TABLE questions (
    id SERIAL PRIMARY KEY,
    course_id INT ,
    question_text TEXT NOT NULL,
    image_url TEXT,
    created_by INT ,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE options (
    id SERIAL PRIMARY KEY,
    question_id INT REFERENCES questions(id) ON DELETE CASCADE,
    option_text TEXT NOT NULL,
    is_correct BOOLEAN DEFAULT FALSE
);

CREATE TABLE exam_questions (
    id SERIAL PRIMARY KEY,
    exam_id INT REFERENCES exams(id) ON DELETE CASCADE,
    question_id INT REFERENCES questions(id) ON DELETE CASCADE,
    UNIQUE(exam_id, question_id)
);

CREATE TABLE student_answers (
    id SERIAL PRIMARY KEY,
    attempt_id INT REFERENCES exam_attempts(id) ON DELETE CASCADE,
    question_id INT REFERENCES questions(id),
    selected_option_id INT REFERENCES options(id)
);
