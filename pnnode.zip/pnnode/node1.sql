CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role VARCHAR(20) CHECK (role IN ('teacher', 'ta', 'student', 'admin'))
);

CREATE TABLE staff_profiles (
    profile_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(50),
    department VARCHAR(100),
    designation VARCHAR(50)
);

CREATE TABLE student_profiles (
    profile_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(50),
    department VARCHAR(30),
    current_semester INTEGER
);
CREATE TABLE departments(
id SERIAL PRIMARY KEY,
name VARCHAR(100) UNIQUE NOT NULL,
code VARCHAR(10) UNIQUE NOT NULL
);

INSERT INTO users(id,username,password_hash,email,r)