CREATE EXTENSION postgres_fdw;
CREATE SERVER node1_server
FOREIGN DATA WRAPPER postgres_fdw
OPTIONS (host '127.0.0.1', port '5440', dbname 'portal_db');

CREATE USER MAPPING FOR node2
SERVER node1_server
OPTIONS (user 'node1', password '12345');

IMPORT FOREIGN SCHEMA public 
FROM SERVER node1_server 
INTO public;

CREATE TABLE courses(
id SERIAL PRIMARY KEY,
name VARCHAR(150) NOT NULL,
code VARCHAR(20) UNIQUE NOT NULL,
department VARCHAR(100),
teacher_id INT
);

CREATE TABLE teacher_courses (
    id SERIAL PRIMARY KEY,
    teacher_id INT,
    course_id INT REFERENCES courses(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(teacher_id, course_id)
);
CREATE TABLE ta_courses (
    id SERIAL PRIMARY KEY,
    teacher_id INT,
    course_id INT REFERENCES courses(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(teacher_id, course_id)
);

CREATE TABLE student_courses (
    id SERIAL PRIMARY KEY,
    student_id INT ,
    course_id INT REFERENCES courses(id) ON DELETE CASCADE,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, course_id)
);
select * from ta_courses;
drop table courses;