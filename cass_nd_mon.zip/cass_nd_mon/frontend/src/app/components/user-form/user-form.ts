import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../services/user';
import { User } from '../../models/user';

@Component({
  selector: 'app-user-form',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './user-form.html'
})
export class UserFormComponent implements OnInit {

  user: User = { name: '', email: '', age: 0 };

  constructor(private userService: UserService) {}

  ngOnInit() {
    this.userService.selectedUser$.subscribe(u => {
      if (u) {
        this.user = { ...u };
      }
    });
  }

  submit() {
    if (this.user.id) {
      
      this.userService.updateUser(this.user.id, this.user).subscribe(() => {
        this.resetForm();
      });
    } else {
      
      this.userService.createUser(this.user).subscribe(() => {
        this.resetForm();
      });
    }
  }

  resetForm() {
    this.user = { name: '', email: '', age: 0 };
    this.userService.setSelectedUser(null);
    this.userService.triggerRefresh();
  }
}