import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserService } from '../../services/user';
import { User } from '../../models/user';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user-list.html'
})
export class UserListComponent implements OnInit {

  users: User[] = [];
  loading: boolean = false;

  constructor(private userService: UserService) {}

  ngOnInit() {
    // optional auto load
    this.loadUsers();

    // auto refresh after CRUD
    this.userService.refresh$.subscribe(() => {
      this.loadUsers();
    });
  }

  loadUsers() {
    this.loading = true;

    this.userService.getUsers().subscribe({
      next: (data) => {
        this.users = data;
        this.loading = false;
      },
      error: (err) => {
        console.error(err);
        this.loading = false;
      }
    });
  }

  deleteUser(id: string) {
    this.userService.deleteUser(id).subscribe(() => {
      this.userService.triggerRefresh();
    });
  }

  editUser(user: User) {
    this.userService.setSelectedUser(user);
  }
}