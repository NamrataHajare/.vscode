const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const cassandra = require("cassandra-driver");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const client = new cassandra.Client({
  contactPoints: ["127.0.0.1"],
  localDataCenter: "datacenter1",
  keyspace: "cloud_db",
});

app.get("/api/users", async (req, res) => {
  const result = await client.execute("SELECT * FROM users");
  res.json(result.rows);
});

app.post("/api/users", async (req, res) => {
  const { name, email, age } = req.body;
  const id = uuidv4();

  const query =
    "INSERT INTO users (id, name, email, age) VALUES (?, ?, ?, ?)";

  await client.execute(query, [id, name, email, age], { prepare: true });

  res.json({ id, name, email, age });
});


app.put("/api/users/:id", async (req, res) => {
  const { id } = req.params;
  const { name, email, age } = req.body;

  const query =
    "UPDATE users SET name=?, email=?, age=? WHERE id=?";

  await client.execute(query, [name, email, age, id], { prepare: true });

  res.json({ message: "Updated" });
});


app.delete("/api/users/:id", async (req, res) => {
  const { id } = req.params;

  await client.execute("DELETE FROM users WHERE id=?", [id], {
    prepare: true,
  });

  res.json({ message: "Deleted" });
});


app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});