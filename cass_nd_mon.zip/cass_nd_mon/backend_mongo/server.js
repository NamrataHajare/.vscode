const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const { MongoClient } = require("mongodb");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const client = new MongoClient("mongodb://127.0.0.1:27017");
//const client = new MongoClient("mongodb://namrata:1234@127.0.0.1:27017/cloud_db?authSource=cloud_db");
let db;

async function connectDB() {
  await client.connect();
  db = client.db("cloud_db");
  console.log("MongoDB Connected");
}

connectDB();

app.get("/api/users", async (req, res) => {
  try {
    const users = await db.collection("users").find().toArray();
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.post("/api/users", async (req, res) => {
  try {
    const { name, email, age } = req.body;
    const id = uuidv4(); 

    await db.collection("users").insertOne({
      id,
      name,
      email,
      age
    });

    res.json({ id, name, email, age });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

app.put("/api/users/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, age } = req.body;

    await db.collection("users").updateOne(
      { id: id },
      { $set: { name, email, age } }
    );

    res.json({ message: "Updated" });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

app.delete("/api/users/:id", async (req, res) => {
  try {
    const { id } = req.params;

    await db.collection("users").deleteOne({ id: id });

    res.json({ message: "Deleted" });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});