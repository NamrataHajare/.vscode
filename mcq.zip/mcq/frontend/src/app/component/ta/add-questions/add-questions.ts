import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ToastService } from '../../../services/toast.service';

@Component({
  selector: 'app-add-question',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-questions.html'
})
export class AddQuestion {

  question = {
    course_id: 1,
    question_text: '',
    option_a: '',
    option_b: '',
    option_c: '',
    option_d: '',
    correct_option: ''
  };

  private toast = inject(ToastService);

  constructor(private http: HttpClient, private router: Router) {}

  addQuestion() {
    const token = localStorage.getItem('token');

    this.http.post(
      'http://localhost:5000/api/auth/question',
      this.question,
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    ).subscribe({
      next: () => {
        this.toast.success('Question added successfully');
        this.router.navigate(['/ta/dashboard']);
      },
      error: (err) => {
        console.error(err);
        this.toast.error('Error adding question');
      }
    });
  }
}
