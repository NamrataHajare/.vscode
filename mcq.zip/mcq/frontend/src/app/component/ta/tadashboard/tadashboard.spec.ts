import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaDashboard } from './tadashboard';

describe('TaDashboard', () => {
  let component: TaDashboard;
  let fixture: ComponentFixture<TaDashboard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TaDashboard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TaDashboard);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
