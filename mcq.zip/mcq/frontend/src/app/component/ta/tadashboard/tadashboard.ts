import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { RouterModule, Router } from '@angular/router';
import { ToastService } from '../../../services/toast.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './tadashboard.html'
})
export class TaDashboard implements OnInit {

  private toast = inject(ToastService);

  questions = signal<any[]>([]);
  totalQuestions = signal(0);
  approved = signal(0);
  pending = signal(0);
  isSidebarOpen = signal(false);

  // Delete modal state
  showDeleteModal = signal(false);
  questionToDelete = signal<number | null>(null);
  isDeleting = signal(false);

  toggleSidebar() {
    this.isSidebarOpen.set(!this.isSidebarOpen());
  }

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit() {
    this.loadQuestions();
  }

  loadQuestions() {
    const token = localStorage.getItem('token');
    const taId = localStorage.getItem('id');

    this.http.get<any[]>(
      `http://localhost:5000/api/auth/questions/${taId}`,
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe(res => {

      this.questions.set(res);
      this.totalQuestions.set(res.length);
      this.approved.set(res.filter((q: any) => q.status === 'approved').length);
      this.pending.set(res.filter((q: any) => q.status === 'pending').length);
    });
  }

  openDeleteModal(id: number): void {
    this.questionToDelete.set(id);
    this.showDeleteModal.set(true);
  }

  closeDeleteModal(): void {
    this.showDeleteModal.set(false);
    this.questionToDelete.set(null);
  }

  deleteQuestion() {
    const id = this.questionToDelete();
    if (!id) return;

    this.isDeleting.set(true);
    const token = localStorage.getItem('token');

    this.http.delete(
      `http://localhost:5000/api/auth/question/${id}`,
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: () => {
        this.isDeleting.set(false);
        this.closeDeleteModal();
        this.toast.success('Question deleted successfully!');
        this.loadQuestions();
      },
      error: (err) => {
        this.isDeleting.set(false);
        this.toast.error('Failed to delete question');
        console.error(err);
      }
    });
  }

  logout() {
    console.log("logout");
    localStorage.clear();
    this.router.navigate(['login']);
  }

}
