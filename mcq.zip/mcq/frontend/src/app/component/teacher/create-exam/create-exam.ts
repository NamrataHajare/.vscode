import { Component, OnInit, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChangeDetectorRef } from '@angular/core';
import { ToastService } from '../../../services/toast.service';

interface Question {
  id?: number;
  question_text: string;
  options?: { id?: number; option_text: string; is_correct: boolean }[];
}

@Component({
  selector: 'app-create-exam',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './create-exam.html'
})
export class CreateExam implements OnInit {

  courseId!: number;
  questionBank: Question[] = [];
  selectedQuestions: Question[] = [];
  manualQuestions: Question[] = [];

  examTitle: string = '';
  api = 'http://localhost:5000/api/auth';

  showNewQuestionForm = false;
  newQuestion: Question = { question_text: '', options: [] };

  private toast = inject(ToastService);

  constructor(private http: HttpClient, private route: ActivatedRoute, private router: Router, private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.courseId = +this.route.snapshot.paramMap.get('courseId')!;
    this.loadCourseQuestions();
  }

  loadCourseQuestions() {
    const token = localStorage.getItem('token');
    this.http.get<Question[]>(`${this.api}/course/${this.courseId}/questions`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: res => {
        this.questionBank = res
        console.log(this.questionBank);
        this.cdr.detectChanges();
      },
      error: err => console.error('Error loading questions:', err)
    });
  }

  toggleQuestion(q: Question) {
    const idx = this.selectedQuestions.findIndex(sq => sq.id === q.id);
    if (idx === -1) this.selectedQuestions.push(q);
    else this.selectedQuestions.splice(idx, 1);
  }

  addManualQuestion() {
    this.manualQuestions.push({ question_text: '', options: [{ option_text: '', is_correct: false }] });
  }

  addOption(qIndex: number) {
    this.manualQuestions[qIndex].options!.push({ option_text: '', is_correct: false });
  }

  removeOption(qIndex: number, optIndex: number) {
    this.manualQuestions[qIndex].options!.splice(optIndex, 1);
  }

  removeManualQuestion(qIndex: number) {
    this.manualQuestions.splice(qIndex, 1);
  }

  createExam() {
    if (!this.examTitle.trim()) {
      this.toast.warning('Enter exam title');
      return;
    }
    if (!this.selectedQuestions.length && !this.manualQuestions.length) {
      this.toast.warning('Select or add at least one question');
      return;
    }

    const token = localStorage.getItem('token');

    const payload = {
      title: this.examTitle,
      course_id: this.courseId,
      selected_question_ids: this.selectedQuestions.map(q => q.id),
      manual_questions: this.manualQuestions.map(q => ({
        question_text: q.question_text,
        options: q.options?.map(o => ({
          option_text: o.option_text,
          is_correct: o.is_correct
        }))
      }))
    };

    this.http.post(`${this.api}/create-exam`, payload, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: res => {
        this.toast.success('Exam created successfully!');
        this.router.navigate(['/teacher/dashbord']);
      },
      error: err => {
        console.error('Error creating exam:', err);
        this.toast.error('Failed to create exam. Please try again.');
      }
    });
  }
}
