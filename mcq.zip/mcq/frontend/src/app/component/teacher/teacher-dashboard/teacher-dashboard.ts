import { Component, OnInit, signal, computed, ChangeDetectorRef, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastService } from '../../../services/toast.service';

interface Course {
  id: number;
  name: string;
  is_assigned: boolean;
}

interface Exam {
  id: number;
  title: string;
  duration_minutes: number;
  start_time: string;
  is_active: boolean;
  course: string;
}

interface ExamAttempt {
  attempt_id: number;
  student_id: number;
  student_name: string;
  student_email: string;
  score: number;
  total_questions: number;
  correct_answers: number;
  submitted_at: string;
  status: string;
}

interface ExamAttemptsResponse {
  attempts: ExamAttempt[];
  stats: {
    totalAttempts: number;
    completedAttempts: number;
    avgScore: number;
  };
}

@Component({
  selector: 'app-teacher-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './teacher-dashboard.html'
})
export class TeacherDashboard implements OnInit {

  private api = 'http://localhost:5000/api/auth';
  private toast = inject(ToastService);
  
  isSidebarOpen = signal<boolean>(false);
  searchQuery = signal<string>('');

  courses: Course[] = [];
  exams: Exam[] = [];

  // Delete Modal state
  showDeleteModal = signal<boolean>(false);
  examToDelete = signal<number | null>(null);
  deleteError = signal<string>('');
  isDeleting = signal<boolean>(false);

  // Exam Attempts Modal state
  showAttemptsModal = signal<boolean>(false);
  selectedExam = signal<Exam | null>(null);
  examAttempts = signal<ExamAttempt[]>([]);
  attemptsStats = signal<{ totalAttempts: number; completedAttempts: number; avgScore: number }>({
    totalAttempts: 0,
    completedAttempts: 0,
    avgScore: 0
  });
  loadingAttempts = signal<boolean>(false);

  loadingCourses = false;
  loadingExams = false;

  filteredCourses = computed(() => {
    const search = this.searchQuery().toLowerCase();
    if (!search) return this.courses;
    return this.courses.filter(c => c.name.toLowerCase().includes(search));
  });

  filteredExams = computed(() => {
    const search = this.searchQuery().toLowerCase();
    if (!search) return this.exams;
    return this.exams.filter(e => 
      e.title.toLowerCase().includes(search) || 
      e.course.toLowerCase().includes(search)
    );
  });

  totalCourses = computed(() => this.courses.length);
  assignedCourses = computed(() => this.courses.filter(c => c.is_assigned).length);
  totalExams = computed(() => this.exams.length);
  activeExams = computed(() => this.exams.filter(e => e.is_active).length);

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadCourses();
    this.loadExams();
  }

  toggleSidebar() {
    this.isSidebarOpen.update(v => !v);
  }

  logout() {
    localStorage.clear();
    window.location.href = '/login';
  }

  loadCourses(): void {
    this.loadingCourses = true;
    const token = localStorage.getItem('token');

    this.http.get<Course[]>(`${this.api}/all-courses`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: (res) => {
        this.courses = res;
        this.loadingCourses = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error(err);
        this.loadingCourses = false;
      }
    });
  }

  enroll(courseId: number): void {
    const token = localStorage.getItem('token');

    this.http.post(`${this.api}/enroll`,
      { course_id: courseId },
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: () => {
        this.toast.success('Enrolled to course successfully!');
        this.loadCourses();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.toast.error('Failed to enroll to course');
        console.error(err);
      }
    });
  }

  goToCreateExam(courseId: number) {
    console.log(courseId);
    this.router.navigate(['/teacher/create-exam', courseId]);
  }

  loadExams(): void {
    this.loadingExams = true;
    const token = localStorage.getItem('token');

    this.http.get<Exam[]>(`${this.api}/exams`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: (res) => {
        this.exams = res;
        this.loadingExams = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error(err);
        this.loadingExams = false;
      }
    });
  }

  // Delete Modal Methods
  openDeleteModal(examId: number): void {
    this.examToDelete.set(examId);
    this.showDeleteModal.set(true);
    this.deleteError.set('');
  }

  closeDeleteModal(): void {
    this.showDeleteModal.set(false);
    this.examToDelete.set(null);
    this.deleteError.set('');
  }

  confirmDeleteExam(): void {
    const examId = this.examToDelete();
    if (!examId) return;

    this.isDeleting.set(true);
    this.deleteError.set('');

    const token = localStorage.getItem('token');

    this.http.delete(`${this.api}/exam/${examId}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: () => {
        this.isDeleting.set(false);
        this.closeDeleteModal();
        this.toast.success('Exam deleted successfully!');
        this.loadExams();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.isDeleting.set(false);
        this.deleteError.set('Failed to delete exam. Please try again.');
        console.error('Error deleting exam:', err);
      }
    });
  }

  // Exam Attempts Methods
  openAttemptsModal(exam: Exam): void {
    this.selectedExam.set(exam);
    this.showAttemptsModal.set(true);
    this.loadExamAttempts(exam.id);
  }

  closeAttemptsModal(): void {
    this.showAttemptsModal.set(false);
    this.selectedExam.set(null);
    this.examAttempts.set([]);
    this.attemptsStats.set({ totalAttempts: 0, completedAttempts: 0, avgScore: 0 });
  }

  loadExamAttempts(examId: number): void {
    this.loadingAttempts.set(true);
    const token = localStorage.getItem('token');

    this.http.get<ExamAttemptsResponse>(`${this.api}/exam/${examId}/attempts`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: (res) => {
        this.examAttempts.set(res.attempts);
        this.attemptsStats.set(res.stats);
        this.loadingAttempts.set(false);
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.toast.error('Failed to load exam attempts');
        console.error('Error loading attempts:', err);
        this.loadingAttempts.set(false);
        this.cdr.detectChanges();
      }
    });
  }
}
