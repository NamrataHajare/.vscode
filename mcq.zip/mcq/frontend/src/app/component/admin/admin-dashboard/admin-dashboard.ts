import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

interface Department {
  id: number;
  name: string;
  code: string;
}

interface Faculty {
  id: number;
  username: string;
  email: string;
  department: string;
  designation: string;
}

interface Student {
  id: number;
  username: string;
  email: string;
  department: string;
  current_semester: number;
}

interface Course {
  id: number;
  name: string;
  code: string;
  department: string;
  teacher_name: string | null;
}

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-dashboard.html'
})
export class AdminDashboard implements OnInit {
  private api = 'http://localhost:5000/api/auth/admin';
  
  // Data signals
  departments = signal<Department[]>([]);
  faculty = signal<Faculty[]>([]);
  students = signal<Student[]>([]);
  courses = signal<Course[]>([]);
  
  // UI state
  activeTab = signal<string>('departments');
  isSidebarOpen = signal<boolean>(false);
  loading = signal<boolean>(false);
  
  // Edit course state
  editingCourse = signal<Course | null>(null);
  
  // Form data
  deptForm = { name: '', code: '' };
  facultyForm = { name: '', email: '', password: '', department: '', designation: 'Faculty' };
  studentForm = { name: '', email: '', password: '', department: '', current_semester: 1 };
  courseForm = { name: '', code: '', department: '', teacher_id: null as number | null };

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.loadDepartments();
    this.loadFaculty();
    this.loadStudents();
    this.loadCourses();
  }

  private getToken() {
    return localStorage.getItem('token');
  }

  private getAuthHeaders() {
    const token = this.getToken();
    return { headers: { Authorization: `Bearer ${token}` } };
  }

  // Tab navigation
  setActiveTab(tab: string) {
    this.activeTab.set(tab);
  }

  toggleSidebar() {
    this.isSidebarOpen.update(v => !v);
  }

  // Load data
  loadDepartments() {
    this.http.get<Department[]>(`${this.api}/departments`, this.getAuthHeaders())
      .subscribe({
        next: (res) => this.departments.set(res),
        error: (err) => console.error('Error loading departments:', err)
      });
  }

  loadFaculty() {
    this.http.get<Faculty[]>(`${this.api}/faculty`, this.getAuthHeaders())
      .subscribe({
        next: (res) => this.faculty.set(res),
        error: (err) => console.error('Error loading faculty:', err)
      });
  }

  loadStudents() {
    this.http.get<Student[]>(`${this.api}/students`, this.getAuthHeaders())
      .subscribe({
        next: (res) => this.students.set(res),
        error: (err) => console.error('Error loading students:', err)
      });
  }

  loadCourses() {
    this.http.get<Course[]>(`${this.api}/courses`, this.getAuthHeaders())
      .subscribe({
        next: (res) => this.courses.set(res),
        error: (err) => console.error('Error loading courses:', err)
      });
  }

  // Create department
  createDepartment() {
    if (!this.deptForm.name || !this.deptForm.code) return;
    
    this.http.post(`${this.api}/departments`, this.deptForm, this.getAuthHeaders())
      .subscribe({
        next: () => {
          this.deptForm = { name: '', code: '' };
          this.loadDepartments();
        },
        error: (err) => console.error('Error creating department:', err)
      });
  }

  // Add faculty
  addFaculty() {
    if (!this.facultyForm.name || !this.facultyForm.email || !this.facultyForm.password || !this.facultyForm.department) return;
    
    this.http.post(`${this.api}/faculty`, this.facultyForm, this.getAuthHeaders())
      .subscribe({
        next: () => {
          this.facultyForm = { name: '', email: '', password: '', department: '', designation: 'Faculty' };
          this.loadFaculty();
        },
        error: (err) => console.error('Error adding faculty:', err)
      });
  }

  // Add student
  addStudent() {
    if (!this.studentForm.name || !this.studentForm.email || !this.studentForm.password || !this.studentForm.department) return;
    
    this.http.post(`${this.api}/students`, this.studentForm, this.getAuthHeaders())
      .subscribe({
        next: () => {
          this.studentForm = { name: '', email: '', password: '', department: '', current_semester: 1 };
          this.loadStudents();
        },
        error: (err) => console.error('Error adding student:', err)
      });
  }

  // Add course
  addCourse() {
    if (!this.courseForm.name || !this.courseForm.code || !this.courseForm.department) return;
    
    this.http.post(`${this.api}/courses`, this.courseForm, this.getAuthHeaders())
      .subscribe({
        next: () => {
          this.courseForm = { name: '', code: '', department: '', teacher_id: null };
          this.loadCourses();
        },
        error: (err) => console.error('Error adding course:', err)
      });
  }

  // Assign teacher to course
  assignTeacher(event: Event) {
    const select = event.target as HTMLSelectElement;
    const value = select.value;
    const courseId = select.getAttribute('data-course-id');
    
    if (value && courseId) {
      this.http.put(`${this.api}/courses/assign`, { course_id: Number(courseId), teacher_id: Number(value) }, this.getAuthHeaders())
        .subscribe({
          next: () => {
            this.loadCourses();
            select.value = '';
          },
          error: (err) => console.error('Error assigning teacher:', err)
        });
    }
  }

  // Edit course - set the course to edit
  editCourse(course: Course) {
    this.editingCourse.set(course);
    this.courseForm = {
      name: course.name,
      code: course.code,
      department: course.department,
      teacher_id: null
    };
  }

  // Update course
  updateCourse() {
    const course = this.editingCourse();
    if (!course || !this.courseForm.name || !this.courseForm.code || !this.courseForm.department) return;

    this.http.put(`${this.api}/courses/${course.id}`, this.courseForm, this.getAuthHeaders())
      .subscribe({
        next: () => {
          this.editingCourse.set(null);
          this.courseForm = { name: '', code: '', department: '', teacher_id: null };
          this.loadCourses();
        },
        error: (err) => console.error('Error updating course:', err)
      });
  }

  // Cancel edit
  cancelEdit() {
    this.editingCourse.set(null);
    this.courseForm = { name: '', code: '', department: '', teacher_id: null };
  }

  // Delete course
  deleteCourse(courseId: number) {
    if (!confirm('Are you sure you want to delete this course?')) return;

    this.http.delete(`${this.api}/courses/${courseId}`, this.getAuthHeaders())
      .subscribe({
        next: () => this.loadCourses(),
        error: (err) => console.error('Error deleting course:', err)
      });
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}
