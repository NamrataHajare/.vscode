import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';
import { ToastService } from '../../../services/toast.service';

@Component({
  selector: 'app-exam-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './exam-page.html'
})
export class ExamPage implements OnInit {

  private api = 'http://localhost:5000/api/auth';
  private toast = inject(ToastService);

  examId!: number;
  attemptId!: number;

  questions = signal<any[]>([]);
  timeLeft = signal<number>(0);
  selectedAnswers = signal<{ [key: number]: number }>({});

  timerInterval: any;

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.examId = Number(this.route.snapshot.paramMap.get('id'));
    this.startExam();
  }

  startExam() {
    const token = localStorage.getItem('token');

    this.http.post<any>(
      `${this.api}/exam/start`,
      { examId: this.examId },
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: (res) => {

        this.attemptId = res.attemptId;

        const startTime = new Date(res.startTime);
        const now = new Date();

        const durationMinutes = 30;
        const totalSeconds = durationMinutes * 60;

        const secondsPassed =
          (now.getTime() - startTime.getTime()) / 1000;

        const remainingSeconds =
          totalSeconds - secondsPassed;

        if (remainingSeconds <= 0) {
          this.toast.warning("Time already over");
          this.submitExam();
          return;
        }

        this.timeLeft.set(Math.floor(remainingSeconds));
        this.startTimer();
        this.loadQuestions();
      },
      error: err => console.error(err)
    });
  }

  startTimer() {
    this.timerInterval = setInterval(() => {
      if (this.timeLeft() > 0) {
        this.timeLeft.update(v => v - 1);
      } else {
        clearInterval(this.timerInterval);
        this.submitExam();
      }
    }, 1000);
  }

  loadQuestions() {
    const token = localStorage.getItem('token');

    this.http.get<any[]>(
      `${this.api}/exam/questions/${this.examId}`,
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: res => {
        this.questions.set(res);
        console.log(res);
        this.cdr.detectChanges();
      },
      error: err => console.error(err)
    });
  }

  selectAnswer(questionId: number, optionId: number) {
    // Update local state for UI highlighting
    this.selectedAnswers.update(answers => ({
      ...answers,
      [questionId]: optionId
    }));

    const token = localStorage.getItem('token');

    this.http.post(
      `${this.api}/exam/answer`,
      {
        attemptId: this.attemptId,
        questionId: questionId,
        selectedOptionId: optionId
      },
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe();
  }

  getSelectedAnswer(questionId: number): number | undefined {
    return this.selectedAnswers()[questionId];
  }

  submitExam() {
    clearInterval(this.timerInterval);

    const token = localStorage.getItem('token');

    this.http.post<any>(
      `${this.api}/exam/submit`,
      { attemptId: this.attemptId },
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: (res: any) => {
        this.toast.success(`Exam submitted! Score: ${res.correct}/${res.total} (${res.percentage}%)`);
        this.router.navigate(['/student/dashboard']);
      },
      error: (err) => {
        this.toast.error('Failed to submit exam. Please try again.');
        console.error(err);
      }
    });
  }
}
