import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

interface Course {
  id: number;
  name: string;
  is_enrolled: boolean;
}

interface Exam {
  id: number;
  title: string;
  course: string;
  status: 'pending' | 'completed' | 'ongoing';
  score?: number;
  duration_minutes: number;
}

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.html'
})
export class Dashboard implements OnInit {

  private api = 'http://localhost:5000/api/auth';

  exams = signal<Exam[]>([]);
  courses = signal<Course[]>([]);
  searchQuery = signal<string>('');

  selectedCourse = signal<string>('All');
  isSidebarOpen = signal<boolean>(false);

  filteredExams = computed(() => {
    let result = this.exams();
    const course = this.selectedCourse();
    const search = this.searchQuery().toLowerCase();
    
    if (course !== 'All') {
      result = result.filter(e => e.course === course);
    }
    if (search) {
      result = result.filter(e => 
        e.title.toLowerCase().includes(search) || 
        e.course.toLowerCase().includes(search)
      );
    }
    return result;
  });

  totalExamsCount = computed(() => this.filteredExams().length);

  completedCount = computed(() =>
    this.filteredExams().filter(e => e.status === 'completed').length
  );

  pendingCount = computed(() =>
    this.filteredExams().filter(e => e.status === 'pending').length
  );

  averageScore = computed(() => {
    const completed = this.exams().filter(e => e.status === 'completed' && e.score !== null);
    if (completed.length === 0) return 0;
    const sum = completed.reduce((acc, e) => acc + (e.score || 0), 0);
    return Math.round(sum / completed.length);
  });

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.loadCourses();
    this.loadExams();
  }

  loadCourses() {
    const token = localStorage.getItem('token');

    this.http.get<Course[]>(`${this.api}/student/courses`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: (res) => this.courses.set(res),
      error: (err) => console.error('Course load error:', err)
    });
  }

  enroll(courseId: number) {
    const token = localStorage.getItem('token');

    this.http.post(`${this.api}/student/enroll`,
      { course_id: courseId },
      { headers: { Authorization: `Bearer ${token}` } }
    ).subscribe({
      next: () => {
        this.loadCourses();
        this.loadExams();
      },
      error: (err) => console.error('Enroll error:', err)
    });
  }

  loadExams() {
    const token = localStorage.getItem('token');

    this.http.get<Exam[]>(`${this.api}/student/exams`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: (res) => this.exams.set(res),
      error: (err) => console.error('Exam load error:', err)
    });
  }

  startExam(examId: number) {
    this.router.navigate(['/exam', examId]);
  }

  toggleSidebar() {
    this.isSidebarOpen.update(v => !v);
  }

  selectCourse(course: string) {
    this.selectedCourse.set(course);
    this.isSidebarOpen.set(false);
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}
