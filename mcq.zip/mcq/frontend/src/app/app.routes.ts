import { Routes } from '@angular/router';
import { Login } from './auth/login/login';
import { Signup } from './auth/signup/signup';
import { Dashboard } from './component/student/dashboard/dashboard';
import { authGuard } from './guards/auth-guard';
import { ExamPage } from './component/student/exam-page/exam-page';
import { TaDashboard } from './component/ta/tadashboard/tadashboard';
import { AddQuestion } from './component/ta/add-questions/add-questions';
import { TeacherDashboard } from './component/teacher/teacher-dashboard/teacher-dashboard';
import { CreateExam } from './component/teacher/create-exam/create-exam';
import { AdminDashboard } from './component/admin/admin-dashboard/admin-dashboard';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: Login },
  { path: 'signup', component: Signup},
  {path:'student/dashboard',component:Dashboard,canActivate:[authGuard]},
  {path: 'exam/:id',component: ExamPage,canActivate:[authGuard]},
  {path:'ta/dashboard',component:TaDashboard,canActivate:[authGuard]},
  {path: 'ta/add-question',component: AddQuestion,canActivate:[authGuard]},
  {path:'teacher/dashbord',component:TeacherDashboard,canActivate:[authGuard]},
  {path:'teacher/create-exam/:courseId',component:CreateExam,canActivate:[authGuard]},
  {path:'admin/dashboard',component:AdminDashboard,canActivate:[authGuard]}
];
