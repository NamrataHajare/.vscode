import { CanActivateFn ,Router} from '@angular/router';
import { Inject } from '@angular/core';
export const authGuard: CanActivateFn = (route, state) => {
  const router = Inject(Router);
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');
  
  if(!token){
    router.navigate(['/login']);
    return false;
  }
  const allowedRoles=route.data?.['roles'];
  if(allowedRoles && !allowedRoles.includes(role)){
    router.navigate(['/login']);
    false;
  }
  return true;
};
