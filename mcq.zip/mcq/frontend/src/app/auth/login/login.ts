import { Component, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  email = '';
  password = '';

  private toast = inject(ToastService);

  constructor(
    private http: HttpClient,
    private router: Router
  ) { }

  login() {
    this.http.post<any>('http://localhost:5000/api/auth/login', {
      email: this.email,
      password: this.password
    }).subscribe({
      next: (res) => {
        localStorage.setItem('token', res.token);
        localStorage.setItem('role', res.role);
        localStorage.setItem('id', res.id);
        console.log(res.role);
        if (res.role == 'teacher') {
          this.router.navigate(['/teacher/dashbord']);
        }
        else if (res.role == 'ta') {
          this.router.navigate(['/ta/dashboard']);
        }
        else if(res.role == 'student') {
          this.router.navigate(['/student/dashboard']);
        }
        else{
          this.router.navigate(['/admin/dashboard']);
        }
      },
      error: (err) => {
        this.toast.error(err.error?.message || 'Login failed');
      }
    });
  }

}
