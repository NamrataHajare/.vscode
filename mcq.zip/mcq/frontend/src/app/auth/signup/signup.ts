import { Component, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './signup.html'
})
export class Signup {
  userData = {
    name: '',
    email: '',
    password: '',
    role: '',
    department: '',
    designation: '',
    current_semester: null
  };

  private toast = inject(ToastService);

  constructor(private http: HttpClient, private router: Router, private cdr: ChangeDetectorRef) {}

  onRoleChange(newRole: string) {
    this.userData.role = newRole;
    if (newRole === 'student') {
      this.userData.designation = '';
    } else {
      this.userData.current_semester = null;
    }
  }

  signup() {

    if (!this.userData.role) {
      this.toast.warning("Please select a role");
      return;
    }

    this.http.post('http://localhost:5000/api/auth/register', this.userData)
      .subscribe({
        next: (res) => {
          this.toast.success('Registration Successful!');
          this.router.navigate(['/login']);
        },
        error: (err) => {
          console.error(err);
          this.toast.error('Registration Failed: ' + err.error.message);
        }
      });
  }
}
