import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ToastComponent } from './component/toast/toast.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FormsModule, ToastComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('mcq-portal');
}
