const pool = require('../config/db');

exports.getStudentCourses = async (req, res) => {
  console.log("enter");
  try {
    const studentId = req.user.id;

    const result = await pool.query(
      `
      SELECT 
        c.id,
        c.name,
        CASE 
          WHEN sc.student_id IS NOT NULL THEN true 
          ELSE false 
        END AS is_enrolled
      FROM courses c
      LEFT JOIN student_courses sc
        ON sc.course_id = c.id
        AND sc.student_id = $1
      ORDER BY c.id DESC
      `,
      [studentId]
    );
    console.log(result);
    res.json(result.rows);

  } catch (error) {
    console.error("Error fetching courses:", error);
    res.status(500).json({ message: "Failed to fetch courses" });
  }
};

exports.enrollCourse = async (req, res) => {
  try {
    const studentId = req.user.id;
    const { course_id } = req.body;

    await pool.query(
      `
      INSERT INTO student_courses (student_id, course_id)
      VALUES ($1, $2)
      ON CONFLICT (student_id, course_id) DO NOTHING
      `,
      [studentId, course_id]
    );

    res.json({ message: "Enrolled successfully" });

  } catch (error) {
    console.error("Enrollment error:", error);
    res.status(500).json({ message: "Enrollment failed" });
  }
};

exports.getStudentExams = async (req, res) => {
  try {
    const studentId = req.user.id;

    const result = await pool.query(
      `
      SELECT 
        e.id,
        e.title,
        e.duration_minutes,
        c.name AS course,
        COALESCE(ea.status, 'pending') AS status,
        ea.score
      FROM exams e
      JOIN courses c ON e.course_id = c.id
      JOIN student_courses sc ON sc.course_id = c.id
      LEFT JOIN exam_attempts ea
        ON ea.exam_id = e.id
        AND ea.student_id = $1
      WHERE sc.student_id = $1
        AND e.is_active = true
      ORDER BY e.id DESC
      `,
      [studentId]
    );

    res.json(result.rows);

  } catch (err) {
    console.error("Error fetching exams:", err);
    res.status(500).json({ error: "Failed to fetch exams" });
  }
};

exports.startExam = async (req, res) => {
  try {
    console.log("cmkd");
    const studentId = req.user.id;
    const { examId } = req.body;
      const attemptResult = await pool.query(
      `SELECT * FROM exam_attempts WHERE id = $1`,
      [examId]
    );
    const attempt = attemptResult.rows[0];
    
    if (attempt.status === 'completed') {
      return res.status(400).json({ message: "Already submitted" });
    }
    const existing = await pool.query(
      `
      SELECT id, start_timestamp, status
      FROM exam_attempts
      WHERE exam_id = $1
        AND student_id = $2
      `,
      [examId, studentId]
    );

    if (existing.rows.length > 0) {
      return res.json({
        attemptId: existing.rows[0].id,
        startTime: existing.rows[0].start_timestamp
      });
    }

    const insert = await pool.query(
      `
      INSERT INTO exam_attempts (exam_id, student_id, status)
      VALUES ($1, $2, 'ongoing')
      RETURNING id, start_timestamp
      `,
      [examId, studentId]
    );

    res.json({
      attemptId: insert.rows[0].id,
      startTime: insert.rows[0].start_timestamp
    });

  } catch (err) {
    console.error("Start exam error:", err);
    res.status(500).json({ message: "Failed to start exam" });
  }
};

exports.submitExam = async (req, res) => {
  try {
    const studentId = req.user.id;
    const { attemptId } = req.body;

    const attemptResult = await pool.query(
      `SELECT * FROM exam_attempts WHERE id = $1`,
      [attemptId]
    );

    if (attemptResult.rows.length === 0) {
      return res.status(404).json({ message: "Attempt not found" });
    }

    const attempt = attemptResult.rows[0];

    if (attempt.student_id !== studentId) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    if (attempt.status === 'completed') {
      return res.status(400).json({ message: "Already submitted" });
    }

    const totalResult = await pool.query(
      `
      SELECT COUNT(*) 
      FROM exam_questions
      WHERE exam_id = $1
      `,
      [attempt.exam_id]
    );

    const total = parseInt(totalResult.rows[0].count);

    const correctResult = await pool.query(
      `
      SELECT COUNT(*) 
      FROM student_answers sa
      JOIN options o 
        ON sa.selected_option_id = o.id
      WHERE sa.attempt_id = $1
        AND o.is_correct = true
      `,
      [attemptId]
    );

    const correct = parseInt(correctResult.rows[0].count);

    const percentage = total === 0 ? 0 : Math.round((correct / total) * 100);

    await pool.query(
      `
      UPDATE exam_attempts
      SET score = $1,
          status = 'completed',
          end_timestamp = NOW()
      WHERE id = $2
      `,
      [percentage, attemptId]
    );

    res.json({
      correct,
      total,
      percentage
    });

  } catch (err) {
    console.error("Submit exam error:", err);
    res.status(500).json({ message: "Submission failed" });
  }
};

exports.saveAnswer = async (req, res) => {
  try {
    const studentId = req.user.id;
    const { attemptId, questionId, selectedOptionId } = req.body;

    if (!attemptId || !questionId || !selectedOptionId) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    const attemptCheck = await pool.query(
      `
      SELECT id, status 
      FROM exam_attempts
      WHERE id = $1
        AND student_id = $2
      `,
      [attemptId, studentId]
    );

    if (attemptCheck.rows.length === 0) {
      return res.status(403).json({ message: "Unauthorized attempt" });
    }

    if (attemptCheck.rows[0].status === 'completed') {
      return res.status(400).json({ message: "Exam already submitted" });
    }

    const existing = await pool.query(
      `
      SELECT id
      FROM student_answers
      WHERE attempt_id = $1
        AND question_id = $2
      `,
      [attemptId, questionId]
    );

    if (existing.rows.length > 0) {
      await pool.query(
        `
        UPDATE student_answers
        SET selected_option_id = $1
        WHERE attempt_id = $2
          AND question_id = $3
        `,
        [selectedOptionId, attemptId, questionId]
      );
    } else {
      await pool.query(
        `
        INSERT INTO student_answers
        (attempt_id, question_id, selected_option_id)
        VALUES ($1, $2, $3)
        `,
        [attemptId, questionId, selectedOptionId]
      );
    }

    res.json({ message: "Answer saved successfully" });

  } catch (err) {
    console.error("Save answer error:", err);
    res.status(500).json({ message: "Failed to save answer" });
  }
};

exports.getExamQuestions = async (req, res) => {
  try {
    const studentId = req.user.id;
    const examId = req.params.examId;

    const check = await pool.query(
      `
      SELECT 1
      FROM exams e
      JOIN student_courses sc ON sc.course_id = e.course_id
      WHERE e.id = $1
        AND sc.student_id = $2
      `,
      [examId, studentId]
    );

    if (check.rows.length === 0) {
      return res.status(403).json({ message: "Not allowed" });
    }

    const result = await pool.query(
      `
      SELECT 
        q.id AS question_id,
        q.question_text,
        o.id AS option_id,
        o.option_text
      FROM exam_questions eq
      JOIN questions q ON eq.question_id = q.id
      JOIN options o ON o.question_id = q.id
      WHERE eq.exam_id = $1
      ORDER BY q.id
      `,
      [examId]
    );

    const questionsMap = {};
     console.log(result);
    result.rows.forEach(row => {
      if (!questionsMap[row.question_id]) {
        questionsMap[row.question_id] = {
          id: row.question_id,
          question_text: row.question_text,
          options: []
        };
      }

      questionsMap[row.question_id].options.push({
        id: row.option_id,
        option_text: row.option_text
      });
    });
    console.log(questionsMap);
    res.json(Object.values(questionsMap));

  } catch (err) {
    console.error("Load questions error:", err);
    res.status(500).json({ message: "Failed to load questions" });
  }
};