const express = require('express');
const router = express.Router();
const pool = require('../config/db');


exports.getAllCoursesWithStatus = async (req, res) => {
  try {
    const teacherId = req.user.id;

    const result = await pool.query(
      `
      SELECT 
        c.id,
        c.name,
        CASE 
          WHEN tc.teacher_id IS NOT NULL THEN true
          ELSE false
        END AS is_assigned
      FROM courses c
      LEFT JOIN teacher_courses tc 
        ON c.id = tc.course_id 
        AND tc.teacher_id = $1
      ORDER BY c.name
      `,
      [teacherId]
    );

    res.json(result.rows);

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch courses" });
  }
};
exports.createExam = async (req, res) => {
  const { title, course_id, selected_question_ids, manual_questions } = req.body;
  const userId = req.user.id;

  try {
    const examResult = await pool.query(
      'INSERT INTO exams(title, course_id, start_time, duration_minutes, is_active) VALUES($1,$2,$3,$4,$5) RETURNING id',
      [title, course_id, null, 60, true]
    );
    const examId = examResult.rows[0].id;

    for (const qId of selected_question_ids) {
      await pool.query(
        'INSERT INTO exam_questions(exam_id, question_id) VALUES($1,$2) ON CONFLICT DO NOTHING',
        [examId, qId]
      );
    }

    for (const q of manual_questions) {
      const questionResult = await pool.query(
        'INSERT INTO questions(course_id, question_text, created_by) VALUES($1,$2,$3) RETURNING id',
        [course_id, q.question_text, userId]
      );
      const questionId = questionResult.rows[0].id;

      for (const opt of q.options) {
        await pool.query(
          'INSERT INTO options(question_id, option_text, is_correct) VALUES($1,$2,$3)',
          [questionId, opt.option_text, opt.is_correct]
        );
      }

      await pool.query(
        'INSERT INTO exam_questions(exam_id, question_id) VALUES($1,$2)',
        [examId, questionId]
      );
    }

    res.json({ success: true, examId });

  } catch (err) {
    console.error('Error creating exam:', err);
    res.status(500).json({ error: 'Failed to create exam', details: err.message });
  }
};
exports.enrollToCourse = async (req, res) => {
  try {
    const teacherId = req.user.id;
    const { course_id } = req.body;

    await pool.query(
      `
      INSERT INTO teacher_courses (teacher_id, course_id)
      VALUES ($1, $2)
      ON CONFLICT (teacher_id, course_id) DO NOTHING
      `,
      [teacherId, course_id]
    );

    res.json({ message: "Enrolled successfully" });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Enrollment failed" });
  }
};

exports.getExamsForTeacher = async (req, res) => {
  try {
    const teacherId = req.user.id;

    const result = await pool.query(
      `
      SELECT 
    e.id,
    e.title,
    e.start_time,
    e.duration_minutes,
    e.is_active,
    c.name AS course
FROM exams e
JOIN courses c ON e.course_id = c.id
JOIN teacher_courses tc ON e.course_id = tc.course_id
WHERE tc.teacher_id = $1
ORDER BY e.start_time DESC;
      `,
      [teacherId]
    );

    res.json(result.rows);

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch exams" });
  }
};

exports.getCourseExam = async (req, res) => {
  const courseId = parseInt(req.params.courseId);

  if (!courseId) return res.status(400).json({ error: 'Invalid courseId' });

  try {
    const query = `
   SELECT q.id, q.question_text, q.image_url, q.created_at,
       json_agg(json_build_object('id', o.id, 'option_text', o.option_text, 'is_correct', o.is_correct)) AS options
FROM questions q
LEFT JOIN options o ON q.id = o.question_id
WHERE q.course_id = $1
GROUP BY q.id
ORDER BY q.id ASC
    `;
    const { rows } = await pool.query(query, [courseId]);

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.deleteExam = async (req, res) => {
  const examId = req.params.id;
  const teacherId = req.user.id;

  if (!examId) {
    return res.status(400).json({ error: 'Invalid exam ID' });
  }

  try {
    // Verify the exam belongs to a course owned by this teacher
    const verifyQuery = `
      SELECT e.id 
      FROM exams e
      JOIN teacher_courses tc ON e.course_id = tc.course_id
      WHERE e.id = $1 AND tc.teacher_id = $2
    `;
    const verifyResult = await pool.query(verifyQuery, [examId, teacherId]);

    if (verifyResult.rows.length === 0) {
      return res.status(403).json({ error: 'You do not have permission to delete this exam' });
    }

    // Delete exam questions first
    await pool.query('DELETE FROM exam_questions WHERE exam_id = $1', [examId]);

    // Delete exam results if table exists
    try {
      await pool.query('DELETE FROM exam_results WHERE exam_id = $1', [examId]);
    } catch (e) {
      
      // Table might not exist
    }

    // Delete the exam
    await pool.query('DELETE FROM exams WHERE id = $1', [examId]);

    res.json({ success: true, message: 'Exam deleted successfully' });

  } catch (err) {
    console.error('Error deleting exam:', err);
    res.status(500).json({ error: 'Failed to delete exam', details: err.message });
  }
};

exports.getExamAttempts = async (req, res) => {
  const examId = req.params.examId;
  const teacherId = req.user.id;

  if (!examId) {
    return res.status(400).json({ error: 'Invalid exam ID' });
  }

  try {
    // Verify the exam belongs to a course owned by this teacher
    const verifyQuery = `
      SELECT e.id 
      FROM exams e
      JOIN teacher_courses tc ON e.course_id = tc.course_id
      WHERE e.id = $1 AND tc.teacher_id = $2
    `;
    const verifyResult = await pool.query(verifyQuery, [examId, teacherId]);

    if (verifyResult.rows.length === 0) {
      return res.status(403).json({ error: 'You do not have permission to view this exam' });
    }

    // Get all attempts for this exam
    const attemptsQuery = `
      SELECT 
        ea.id as attempt_id,
        ea.student_id,
        u.username as student_name,
        u.email as student_email,
        ea.score,
        ea.status as attempt_status,
        ea.start_timestamp,
        ea.end_timestamp
      FROM exam_attempts ea
      JOIN users u ON ea.student_id = u.id
      WHERE ea.exam_id = $1
      ORDER BY ea.start_timestamp DESC
    `;
    
    const result = await pool.query(attemptsQuery, [examId]);
    
    const attempts = result.rows.map(row => ({
      attempt_id: row.attempt_id,
      student_id: row.student_id,
      student_name: row.student_name,
      student_email: row.student_email,
      score: row.score,
      status: row.attempt_status === 'completed' ? 'Completed' : (row.attempt_status === 'ongoing' ? 'In Progress' : row.attempt_status),
      submitted_at: row.end_timestamp
    }));
    
    const completedAttempts = attempts.filter(r => r.status === 'Completed');
    const totalAttempts = attempts.length;
    const avgScore = completedAttempts.length > 0 
      ? Math.round(completedAttempts.reduce((sum, r) => sum + (r.score || 0), 0) / completedAttempts.length)
      : 0;

    res.json({
      attempts: attempts,
      stats: {
        totalAttempts,
        completedAttempts: completedAttempts.length,
        avgScore
      }
    });

  } catch (err) {
    console.error('Error fetching exam attempts:', err);
    res.status(500).json({ error: 'Failed to fetch exam attempts', details: err.message });
  }
};
