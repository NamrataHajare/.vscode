const pool = require('../config/db');

// Get all departments
exports.getDepartments = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM departments ORDER BY name');
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching departments' });
    }
};

// Create new department
exports.createDepartment = async (req, res) => {
    const { name, code } = req.body;
    if (!name || !code) {
        return res.status(400).json({ message: 'Name and code are required' });
    }
    try {
        const result = await pool.query(
            'INSERT INTO departments (name, code) VALUES ($1, $2) RETURNING *',
            [name, code]
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating department' });
    }
};

// Get all faculty members (teachers)
exports.getFaculty = async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT u.id, u.username, u.email, sp.department, sp.designation 
            FROM users u 
            LEFT JOIN staff_profiles sp ON u.id = sp.user_id 
            WHERE u.role = 'teacher'
            ORDER BY u.username
        `);
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching faculty' });
    }
};

// Add new faculty member (teacher)
exports.addFaculty = async (req, res) => {
    const { name, email, password, department, designation } = req.body;
    if (!name || !email || !password || !department) {
        return res.status(400).json({ message: 'All fields are required' });
    }
    
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        
        const userResult = await client.query(
            'INSERT INTO users (username, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING id',
            [name, email, password, 'teacher']
        );
        const userId = userResult.rows[0].id;
        
        await client.query(
            'INSERT INTO staff_profiles (user_id, name, department, designation) VALUES ($1, $2, $3, $4)',
            [userId, name, department, designation || 'Faculty']
        );
        
        await client.query('COMMIT');
        res.status(201).json({ message: 'Faculty added successfully', userId });
    } catch (error) {
        await client.query('ROLLBACK');
        console.error(error);
        res.status(500).json({ message: 'Error adding faculty' });
    } finally {
        client.release();
    }
};

// Get all students
exports.getStudents = async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT u.id, u.username, u.email, sp.department, sp.current_semester 
            FROM users u 
            LEFT JOIN student_profiles sp ON u.id = sp.user_id 
            WHERE u.role = 'student'
            ORDER BY u.username
        `);
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching students' });
    }
};

// Add new student
exports.addStudent = async (req, res) => {
    const { name, email, password, department, current_semester } = req.body;
    if (!name || !email || !password || !department) {
        return res.status(400).json({ message: 'All fields are required' });
    }
    
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        
        const userResult = await client.query(
            'INSERT INTO users (username, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING id',
            [name, email, password, 'student']
        );
        const userId = userResult.rows[0].id;
        
        await client.query(
            'INSERT INTO student_profiles (user_id, name, department, current_semester) VALUES ($1, $2, $3, $4)',
            [userId, name, department, current_semester || 1]
        );
        
        await client.query('COMMIT');
        res.status(201).json({ message: 'Student added successfully', userId });
    } catch (error) {
        await client.query('ROLLBACK');
        console.error(error);
        res.status(500).json({ message: 'Error adding student' });
    } finally {
        client.release();
    }
};

// Get all courses
exports.getCourses = async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT c.id, c.name
            FROM courses c
            ORDER BY c.name
        `);
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching courses' });
    }
};

// Add new course to department
exports.addCourse = async (req, res) => {
    const { name, code, department, teacher_id } = req.body;
    if (!name || !code || !department) {
        return res.status(400).json({ message: 'Name, code, and department are required' });
    }
    try {
        const result = await pool.query(
            'INSERT INTO courses (name) VALUES ($1) RETURNING *',
            [name]
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error adding course' });
    }
};

// Assign teacher to course
exports.assignTeacherToCourse = async (req, res) => {
    const { course_id, teacher_id } = req.body;
    if (!course_id || !teacher_id) {
        return res.status(400).json({ message: 'Course and teacher are required' });
    }
    try {
        await pool.query(
            'UPDATE courses SET teacher_id = $1 WHERE id = $2',
            [teacher_id, course_id]
        );
        res.json({ message: 'Teacher assigned to course successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error assigning teacher' });
    }
};

// Update course
exports.updateCourse = async (req, res) => {
    const { id } = req.params;
    const { name, code, department } = req.body;
    if (!name || !code || !department) {
        return res.status(400).json({ message: 'Name, code, and department are required' });
    }
    try {
        const result = await pool.query(
            'UPDATE courses SET name = $1, code = $2, department = $3 WHERE id = $4 RETURNING *',
            [name, code, department, id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Course not found' });
        }
        res.json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error updating course' });
    }
};

// Delete course
exports.deleteCourse = async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('DELETE FROM courses WHERE id = $1', [id]);
        res.json({ message: 'Course deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting course' });
    }
};
