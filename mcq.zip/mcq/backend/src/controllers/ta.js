const express = require('express');
const router = express.Router();
const pool = require('../config/db');

exports.addQuestion = async (req, res) => {
  const client = await pool.connect();

  try {
    const {
      course_id,
      question_text,
      option_a,
      option_b,
      option_c,
      option_d,
      correct_option,
      image_url
    } = req.body;

    const taId = req.user.id;

    await client.query("BEGIN");
    const questionResult = await client.query(
      `INSERT INTO questions
       (course_id, question_text, image_url, created_by)
       VALUES ($1, $2, $3, $4)
       RETURNING id`,
      [course_id, question_text, image_url || null, taId]
    );

    const questionId = questionResult.rows[0].id;

    const options = [
      { text: option_a, correct: correct_option === 'A' },
      { text: option_b, correct: correct_option === 'B' },
      { text: option_c, correct: correct_option === 'C' },
      { text: option_d, correct: correct_option === 'D' }
    ];

    for (let opt of options) {
      await client.query(
        `INSERT INTO options (question_id, option_text, is_correct)
         VALUES ($1, $2, $3)`,
        [questionId, opt.text, opt.correct]
      );
    }

    await client.query("COMMIT");

    res.status(201).json({
      message: "Question added successfully",
      question_id: questionId
    });

  } catch (err) {
    await client.query("ROLLBACK");
    console.error(err);
    res.status(500).json({ error: err.message });

  } finally {
    client.release();
  }
};
exports.getQuestions = async (req, res) => {
  try {

    const taId = req.params.taId;

    const result = await pool.query(
      `SELECT *
       FROM questions
       WHERE created_by = $1
       ORDER BY created_at DESC`,
      [taId]
    );

    res.json(result.rows);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
};
exports.deleteQuestion = async (req, res) => {
  try {

    const id = req.params.id;
    const taId = req.user.id;

    await pool.query(
      `DELETE FROM questions
       WHERE id = $1 AND created_by = $2`,
      [id, taId]
    );

    res.json({ message: 'Question deleted' });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
};
exports.updateQuestion = async (req, res) => {
  try {

    const id = req.params.id;
    const taId = req.user.id;

    const {
      question_text,
      option_a,
      option_b,
      option_c,
      option_d,
      correct_option
    } = req.body;

    const result = await pool.query(
      `UPDATE questions
       SET question_text=$1,
           option_a=$2,
           option_b=$3,
           option_c=$4,
           option_d=$5,
           correct_option=$6,
           status='pending'
       WHERE id=$7 AND created_by=$8
       RETURNING *`,
      [
        question_text,
        option_a,
        option_b,
        option_c,
        option_d,
        correct_option,
        id,
        taId
      ]
    );

    res.json(result.rows[0]);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
};