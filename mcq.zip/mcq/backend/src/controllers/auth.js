const pool = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
    const { name, email, password, role, department, designation, current_semester } = req.body;

    if (!email || !name || !password || !role) {
        return res.status(400).json({ message: 'ALL FIELDS ARE REQUIRED' });
    }

    const client = await pool.connect();
    try {
        await client.query('BEGIN');

        const userResult = await client.query(
            'INSERT INTO users (username, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING id',
            [name, email, password, role]
        );
        const userId = userResult.rows[0].id;

        if (role === 'student') {
            await client.query(
                'INSERT INTO student_profiles (user_id, name, department, current_semester) VALUES ($1, $2, $3, $4)',
                [userId, name, department, current_semester]
            );
        } else if (role === 'teacher' || role === 'ta') {
            await client.query(
                'INSERT INTO staff_profiles (user_id, name, department, designation) VALUES ($1, $2, $3, $4)',
                [userId, name, department, designation]
            );
        }

        await client.query('COMMIT');
        res.status(201).json({ message: 'User registered successfully', userId });

    } catch (error) {
        await client.query('ROLLBACK');
        console.error(error);
        res.status(500).json({ message: 'Registration failed', error: error.message });
    } finally {
        client.release();
    }
};
exports.login = async (req, res) => {
    
  const { email, password } = req.body;
  
  const result = await pool.query(
    'SELECT * FROM users WHERE email=$1',
    [email]
  );
 
  if (result.rows.length === 0)
    return res.status(401).json({ message: 'Invalid credentials' });

  const user = result.rows[0];

  if (user.password_hash != password) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
 
  const token = jwt.sign(
    { id: user.id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: '1h' }
  );

  res.json({ token, role: user.role,id : user.id });
};
