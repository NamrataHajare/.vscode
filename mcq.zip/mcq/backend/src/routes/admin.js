const express = require('express');
const router = express.Router();
const {auth, authorize} = require('../middleware/auth');
const admin = require('../controllers/admin');

// Admin routes - only admin can access
router.get('/departments', auth, authorize('admin'), admin.getDepartments);
router.post('/departments', auth, authorize('admin'), admin.createDepartment);
router.get('/faculty', auth, authorize('admin'), admin.getFaculty);
router.post('/faculty', auth, authorize('admin'), admin.addFaculty);
router.get('/students', auth, authorize('admin'), admin.getStudents);
router.post('/students', auth, authorize('admin'), admin.addStudent);
router.get('/courses', auth, authorize('admin'), admin.getCourses);
router.post('/courses', auth, authorize('admin'), admin.addCourse);
router.put('/courses/assign', auth, authorize('admin'), admin.assignTeacherToCourse);
router.put('/courses/:id', auth, authorize('admin'), admin.updateCourse);
router.delete('/courses/:id', auth, authorize('admin'), admin.deleteCourse);

module.exports = router;
