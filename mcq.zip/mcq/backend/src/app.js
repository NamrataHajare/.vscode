const express = require("express");
const cors = require("cors");
require('dotenv').config();
const app = express();
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');

app.use(cors());
app.use(express.json());
app.use('/api/auth', authRoutes);
app.use('/api/auth/admin', adminRoutes);


const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});