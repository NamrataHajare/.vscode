

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
	email VARCHAR(100) UNIQUE NOT NULL,
    role VARCHAR(20) CHECK (role IN ('teacher', 'ta', 'student'))
);
ALTER TABLE users 
DROP CONSTRAINT users_role_check;

ALTER TABLE users 
ADD CONSTRAINT users_role_check 
CHECK (role IN ('teacher', 'ta', 'student', 'admin'));
INSERT INTO users (username, password_hash, email, role)
VALUES (
    'admin',
    'admin123',
    'admin@gmail.com',
    'admin'
);

CREATE TABLE staff_profiles (
    profile_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
	name VARCHAR(50),
    department VARCHAR(100),
    designation VARCHAR(50) 
);


CREATE TABLE student_profiles (
    profile_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(50),
	department VARCHAR(30),
    current_semester INTEGER
);

CREATE TABLE courses (
    id SERIAL PRIMARY KEY,
    name VARCHAR(30) UNIQUE NOT NULL
);

CREATE TABLE exams (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    start_time TIMESTAMP,
    duration_minutes INT,
    course_id INT REFERENCES courses(id),
    is_active BOOLEAN DEFAULT true
);

CREATE TABLE exam_attempts (
    id SERIAL PRIMARY KEY,
    student_id INT REFERENCES users(id),
    exam_id INT REFERENCES exams(id),
    status VARCHAR(20) DEFAULT 'available',
    score DECIMAL(5,2),
    start_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    end_timestamp TIMESTAMP
);

CREATE TABLE questions (
    id SERIAL PRIMARY KEY,
    course_id INT REFERENCES courses(id) ON DELETE CASCADE,
    question_text TEXT NOT NULL,
    image_url TEXT,
    created_by INT REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
delete from exam_attempts;
insert into questions(course_id,question_text)values(4,'What is the main function of the OSI model in networking?');
INSERT INTO options (question_id, option_text, is_correct)
VALUES 
(4, 'Option A', false),
(4, 'Option B', true),
(4, 'Option C', false),
(4, 'Option D', false);
CREATE TABLE options (
    id SERIAL PRIMARY KEY,
    question_id INT REFERENCES questions(id) ON DELETE CASCADE,
    option_text TEXT NOT NULL,
    is_correct BOOLEAN DEFAULT FALSE
);

CREATE TABLE exam_questions (
    id SERIAL PRIMARY KEY,
    exam_id INT REFERENCES exams(id) ON DELETE CASCADE,
    question_id INT REFERENCES questions(id) ON DELETE CASCADE,
    UNIQUE(exam_id, question_id)
);

CREATE TABLE student_answers (
    id SERIAL PRIMARY KEY,
    attempt_id INT REFERENCES exam_attempts(id) ON DELETE CASCADE,
    question_id INT REFERENCES questions(id),
    selected_option_id INT REFERENCES options(id)
);
select * from users;
SELECT * FROM exam_questions;
INSERT INTO courses (name) VALUES ('CSE');

CREATE TABLE teacher_courses (
    id SERIAL PRIMARY KEY,
    teacher_id INT REFERENCES users(id) ON DELETE CASCADE,
    course_id INT REFERENCES courses(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(teacher_id, course_id)
);
CREATE TABLE student_courses (
    id SERIAL PRIMARY KEY,
    student_id INT REFERENCES users(id) ON DELETE CASCADE,
    course_id INT REFERENCES courses(id) ON DELETE CASCADE,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, course_id)
);

INSERT INTO courses (name) VALUES 
('DBMS'),
('Operating Systems'),
('Computer Networks'),
('Java Programming'),
('Data Structures');

delete from exam_attempts where student_id=4 ;

select * from exam_attempts;
