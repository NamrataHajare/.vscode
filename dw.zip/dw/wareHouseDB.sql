//enable forgin data wrapper
CREATE EXTENSION postgres_fdw;
//Connect to Headquarter DB
CREATE SERVER hq_server
FOREIGN DATA WRAPPER postgres_fdw
OPTIONS (dbname 'headquarter_db', host 'localhost');
//user mapping 
CREATE USER MAPPING FOR CURRENT_USER
SERVER hq_server
OPTIONS (user 'postgres', password 'root123');
//import tables
IMPORT FOREIGN SCHEMA public
FROM SERVER hq_server
INTO public;

//connect to sales db
CREATE SERVER sales_server
FOREIGN DATA WRAPPER postgres_fdw
OPTIONS (dbname 'sales_db', host 'localhost');

//user mapping
CREATE USER MAPPING FOR CURRENT_USER
SERVER sales_server
OPTIONS (user 'postgres', password 'root123');

//import tables
IMPORT FOREIGN SCHEMA public
FROM SERVER sales_server
INTO public;



CREATE TABLE dim_customer (
    customer_key SERIAL PRIMARY KEY,
    customer_id INT,
    customer_name VARCHAR(100),
    city_id INT,
    first_order_date DATE,
    customer_type VARCHAR(20)
);

INSERT INTO dim_customer
(customer_id, customer_name, city_id, first_order_date, customer_type)
SELECT c.customer_id,
       c.customer_name,
       c.city_id,
       c.first_order_date,
       CASE
           WHEN w.customer_id IS NOT NULL AND m.customer_id IS NOT NULL THEN 'Dual'
           WHEN w.customer_id IS NOT NULL THEN 'Walk-in'
           WHEN m.customer_id IS NOT NULL THEN 'Mail-order'
       END
FROM customer c
LEFT JOIN walk_in_customers w
ON c.customer_id = w.customer_id
LEFT JOIN mail_order_customers m
ON c.customer_id = m.customer_id;

select * from dim_customer;


CREATE TABLE dim_store (
    store_key SERIAL PRIMARY KEY,
    store_id INT,
    city_id INT,
    city_name VARCHAR(100),
    state VARCHAR(100),
    phone VARCHAR(20),
    headquarter_addr VARCHAR(200)
);

INSERT INTO dim_store
(store_id, city_id, city_name, state, phone, headquarter_addr)
SELECT s.store_id,
       s.city_id,
       h.city_name,
       h.state,
       s.phone,
       h.headquarter_addr
FROM stores s
JOIN headqarters h
ON s.city_id = h.city_id;

select * from dim_store;



CREATE TABLE dim_item (
    item_key SERIAL PRIMARY KEY,
    item_id INT,
    description VARCHAR(255),
    size VARCHAR(50),
    weight DECIMAL,
    unit_price DECIMAL
);

INSERT INTO dim_item
(item_id, description, size, weight, unit_price)
SELECT item_id, description, size, weight, unit_price
FROM items;

select * from dim_item;


CREATE TABLE dim_time (
    time_key SERIAL PRIMARY KEY,
    order_date DATE,
    day INT,
    month INT,
    year INT,
    quarter INT
);

INSERT INTO dim_time
(order_date, day, month, year, quarter)
SELECT DISTINCT order_date,
       EXTRACT(DAY FROM order_date),
       EXTRACT(MONTH FROM order_date),
       EXTRACT(YEAR FROM order_date),
       EXTRACT(QUARTER FROM order_date)
FROM orders;

select * from dim_time;

CREATE TABLE fact_sales (
    fact_key SERIAL PRIMARY KEY,
    customer_key INT REFERENCES dim_customer(customer_key),
    store_key INT REFERENCES dim_store(store_key),
    item_key INT REFERENCES dim_item(item_key),
    time_key INT REFERENCES dim_time(time_key),
    quantity_ordered INT,
    ordered_price DECIMAL,
    quantity_held INT
);

INSERT INTO fact_sales
(customer_key, store_key, item_key, time_key,
 quantity_ordered, ordered_price, quantity_held)
SELECT dc.customer_key,
       ds.store_key,
       di.item_key,
       dt.time_key,
       oi.quantity_ordered,
       oi.ordered_price,
       si.quantity_held
FROM orders o
JOIN ordered_item oi ON o.order_no = oi.order_no
JOIN dim_customer dc ON dc.customer_id = o.customer_id
JOIN dim_item di ON di.item_id = oi.item_id
JOIN stored_items si ON si.item_id = oi.item_id
JOIN dim_store ds ON ds.store_id = si.store_id
JOIN dim_time dt ON dt.order_date = o.order_date;

//olap operations
//roll-up
SELECT ds.city_name,
       SUM(fs.quantity_ordered)
FROM fact_sales fs
JOIN dim_store ds ON fs.store_key = ds.store_key
GROUP BY ds.city_name;

//drill-down
SELECT ds.city_name,
       ds.store_id,
       SUM(fs.quantity_ordered)
FROM fact_sales fs
JOIN dim_store ds ON fs.store_key = ds.store_key
GROUP BY ds.city_name, ds.store_id;

//slice
SELECT *
FROM fact_sales fs
JOIN dim_item di ON fs.item_key = di.item_key
WHERE di.description = 'Laptop';

//dice
SELECT *
FROM fact_sales fs
JOIN dim_item di ON fs.item_key = di.item_key
JOIN dim_store ds ON fs.store_key = ds.store_key
WHERE di.description = 'Laptop'
AND ds.city_name = 'Mumbai';


//Stores holding particular item
SELECT ds.store_id, ds.city_name, ds.state,
       ds.phone, di.description, di.size,
       di.weight, di.unit_price
FROM fact_sales fs
JOIN dim_store ds ON fs.store_key = ds.store_key
JOIN dim_item di ON fs.item_key = di.item_key
WHERE di.description = 'Laptop';
// Orders fulfilled by given store
SELECT 
    dc.customer_name,
    dt.order_date,
    ds.store_id,
    fs.quantity_ordered
FROM fact_sales fs
JOIN dim_store ds ON fs.store_key = ds.store_key
JOIN dim_customer dc ON fs.customer_key = dc.customer_key
JOIN dim_time dt ON fs.time_key = dt.time_key
WHERE ds.store_id = 11;
//Stores holding items ordered by given customer
SELECT DISTINCT ds.store_id, ds.city_name, ds.phone
FROM fact_sales fs
JOIN dim_store ds ON fs.store_key = ds.store_key
JOIN dim_customer dc ON fs.customer_key = dc.customer_key
WHERE dc.customer_name = 'ABC';
//HQ address of stores holding stock above level
SELECT DISTINCT
    ds.headquarter_addr,
    ds.city_name,
    ds.state
FROM fact_sales fs
JOIN dim_store ds ON fs.store_key = ds.store_key
WHERE fs.quantity_held > 40;
// Customer order items with stores
SELECT 
    dc.customer_name,
    dt.order_date,
    di.description,
    ds.store_id,
    ds.city_name,
    fs.quantity_ordered
FROM fact_sales fs
JOIN dim_customer dc ON fs.customer_key = dc.customer_key
JOIN dim_item di ON fs.item_key = di.item_key
JOIN dim_store ds ON fs.store_key = ds.store_key
JOIN dim_time dt ON fs.time_key = dt.time_key;
//City & state of customer
SELECT ds.city_name, ds.state
FROM dim_customer dc
JOIN dim_store ds ON dc.city_id = ds.city_id
WHERE dc.customer_name = 'ABC'
LIMIT 1;

//Stock level of item in city
SELECT ds.store_id, SUM(fs.quantity_held)
FROM fact_sales fs
JOIN dim_store ds ON fs.store_key = ds.store_key
JOIN dim_item di ON fs.item_key = di.item_key
WHERE di.description = 'Laptop'
AND ds.city_name = 'Mumbai'
GROUP BY ds.store_id;
//Items, quantity, customer, store & city of order
SELECT di.description,
       fs.quantity_ordered,
       dc.customer_name,
       ds.store_id,
       ds.city_name
FROM fact_sales fs
JOIN dim_item di ON fs.item_key = di.item_key
JOIN dim_customer dc ON fs.customer_key = dc.customer_key
JOIN dim_store ds ON fs.store_key = ds.store_key
JOIN dim_time dt ON fs.time_key = dt.time_key
WHERE dt.order_date = '2024-04-01';

//Walk-in, Mail-order & Dual customers
SELECT 
    customer_name,
    customer_type
FROM dim_customer;
//separte wall in customers
SELECT customer_name
FROM dim_customer
WHERE customer_type = 'Walk-in';
//Mail-order Customers
SELECT customer_name
FROM dim_customer
WHERE customer_type = 'Mail-order';
//dual customers
SELECT customer_name
FROM dim_customer
WHERE customer_type = 'Dual';


















