//headquarters
CREATE TABLE headqarters (
    city_id INT PRIMARY KEY,
    city_name VARCHAR(100),
    headquarter_addr VARCHAR(200),
    state VARCHAR(100),
    time TIMESTAMP
);
//stores
CREATE TABLE stores (
    store_id INT PRIMARY KEY,
    city_id INT,
    phone VARCHAR(20),
    time TIMESTAMP,
    FOREIGN KEY (city_id) REFERENCES headqarters(city_id)
);
//items
CREATE TABLE items (
    item_id INT PRIMARY KEY,
    description VARCHAR(100),
    size VARCHAR(50),
    weight DECIMAL,
    unit_price DECIMAL,
    time TIMESTAMP
);
//stored items
CREATE TABLE stored_items (
    store_id INT,
    item_id INT,
    quantity_held INT,
    time TIMESTAMP,
    PRIMARY KEY (store_id, item_id),
    FOREIGN KEY (store_id) REFERENCES stores(store_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id)
);
//orders
CREATE TABLE orders (
    order_no INT PRIMARY KEY,
    order_date DATE,
    customer_id INT
);
//orders items
CREATE TABLE ordered_item (
    order_no INT,
    item_id INT,
    quantity_ordered INT,
    ordered_price DECIMAL,
    time TIMESTAMP,
    PRIMARY KEY (order_no, item_id),
    FOREIGN KEY (order_no) REFERENCES orders(order_no),
    FOREIGN KEY (item_id) REFERENCES items(item_id)
);
INSERT INTO headqarters VALUES
(101,'Mumbai','HQ Mumbai','Maharashtra',NOW()),
(102,'Pune','HQ Pune','Maharashtra',NOW());
INSERT INTO stores VALUES
(1,101,'9876543210',NOW()),
(2,102,'9123456780',NOW());
INSERT INTO items VALUES
(1,'Laptop','Medium',2.5,50000,NOW()),
(2,'Mobile','Small',0.5,20000,NOW());
INSERT INTO stored_items VALUES
(1,1,50,NOW()),
(1,2,30,NOW()),
(2,1,20,NOW());
INSERT INTO orders VALUES
(1001,'2024-04-01',1),
(1002,'2024-04-02',2);
INSERT INTO ordered_item VALUES
(1001,1,2,50000,NOW()),
(1002,2,1,20000,NOW());






