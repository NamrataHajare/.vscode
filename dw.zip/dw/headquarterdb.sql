CREATE TABLE customer (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100),
    city_id INT,
    first_order_date DATE
);
//walk in customers
CREATE TABLE walk_in_customers (
    customer_id INT PRIMARY KEY,
    tourism_guide VARCHAR(100),
    time TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
);
//mail order customers
CREATE TABLE mail_order_customers (
    customer_id INT PRIMARY KEY,
    post_address VARCHAR(200),
    time TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
);
INSERT INTO customer VALUES
(1,'ABC',101,'2024-01-10'),
(2,'PQR',102,'2024-02-15'),
(3,'XYZ',101,'2024-03-05');
INSERT INTO walk_in_customers VALUES
(1,'Guide1',NOW()),
(3,'Guide2',NOW());
INSERT INTO mail_order_customers VALUES
(2,'Mumbai Address',NOW()),
(3,'Pune Address',NOW());



