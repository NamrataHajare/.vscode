// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { HttpClient } from '@angular/common/http';

// @Component({
//   selector: 'app-student',
//   standalone: true,
//   imports: [CommonModule, FormsModule],
//   template: `
//     <div class="max-w-xl mx-auto p-6 bg-gray-100 rounded shadow">
//       <h1 class="text-2xl font-bold mb-4 text-center">Add Student</h1>

//       <form (ngSubmit)="addStudent()" class="space-y-4">
//         <input
//           type="number"
//           placeholder="Roll No"
//           [(ngModel)]="student.roll"
//           name="roll"
//           class="w-full p-2 border rounded"
//           required
//         />

//         <input
//           type="text"
//           placeholder="Name"
//           [(ngModel)]="student.name"
//           name="name"
//           class="w-full p-2 border rounded"
//           required
//         />

//         <input
//           type="text"
//           placeholder="Department"
//           [(ngModel)]="student.dept"
//           name="dept"
//           class="w-full p-2 border rounded"
//           required
//         />

//         <button
//           type="submit"
//           class="bg-blue-600 text-white px-4 py-2 rounded w-full"
//         >
//           Add Student
//         </button>
//       </form>
//     </div>
//   `
// })
// export class StudentComponent {
//   student = {
//     roll: 0,
//     name: '',
//     dept: ''
//   };

//   constructor(private http: HttpClient) {}

//   addStudent() {
//     this.http.post('http://localhost:3000/students', this.student)
//       .subscribe({
//         next: () => {
//           alert('Student added successfully');
//           this.student = { roll: 0, name: '', dept: '' };
//         },
//         error: (err) => {
//           console.error(err);
//           alert('Error adding student');
//         }
//       });
//   }
// }

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-student',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="max-w-xl mx-auto p-6 bg-gray-100 rounded shadow">
      <h1 class="text-2xl font-bold mb-4 text-center">Student Management</h1>

      <!-- ADD STUDENT -->
      <form (ngSubmit)="addStudent()" class="space-y-4">
        <input type="number" placeholder="Roll No"
          [(ngModel)]="student.roll" name="roll"
          class="w-full p-2 border rounded" required />

        <input type="text" placeholder="Name"
          [(ngModel)]="student.name" name="name"
          class="w-full p-2 border rounded" required />

        <input type="text" placeholder="Department"
          [(ngModel)]="student.dept" name="dept"
          class="w-full p-2 border rounded" required />

        
          <button type="submit"
  class="bg-blue-600 text-white px-4 py-2 rounded w-full">
  Add Student
</button>

<button
  type="button"
  (click)="updateStudent()"
  class="bg-blue-600 text-white px-4 py-2 rounded w-full">
  Update Student
</button>
         
      </form>

      <!-- DISPLAY BUTTON -->
      <button
        (click)="loadStudents()"
        class="mt-4 bg-green-600 text-white px-4 py-2 rounded w-full">
        Display Students
      </button>

      <!-- STUDENT TABLE -->
      <table *ngIf="students.length > 0"
        class="w-full mt-4 border border-collapse">
        <th>Roll No</th>
        <th>Name</th>
        <th>Dept</th>
  <th class="border p-2">Action</th>

    <tr *ngFor="let s of students">
  <td class="border p-2">{{ s.roll }}</td>
  <td class="border p-2">{{ s.name }}</td>
  <td class="border p-2">{{ s.dept }}</td>
  <td class="border p-2">
    <button
      class="bg-yellow-500 text-white px-2 py-1 rounded"
      (click)="editStudent(s)">
      Edit
    </button>
     <button
      class="bg-red-600 text-white px-2 py-1 rounded"
      (click)="deleteStudent(s.roll)">
      Delete
    </button>
  </td>
</tr>
      </table>
    </div>
  `
})
export class StudentComponent {

  student = { roll: 0, name: '', dept: '' };
  students: any[] = [];

  constructor(private http: HttpClient) {}
  
  editStudent(s: any) {
  this.student = { ...s };
}


  addStudent() {
    this.http.post('http://localhost:3000/students', this.student)
      .subscribe({
        next: () => {
          alert('Student added successfully');
          this.student = { roll: 0, name: '', dept: '' };
        },
        error: () => alert('Error adding student')
      });
  }

  updateStudent() {
  this.http.put(
    `http://localhost:3000/students/${this.student.roll}`,
    this.student
  ).subscribe({
    next: () => {
      alert('Student updated successfully');
      this.loadStudents();
      this.student = { roll: 0, name: '', dept: '' };
    },
    error: () => alert('Update failed')
  });
}

deleteStudent(roll: number) {
  if (!confirm('Are you sure you want to delete this student?')) return;

  this.http.delete(`http://localhost:3000/students/${roll}`)
    .subscribe({
      next: () => {
        alert('Student deleted successfully');
        this.loadStudents();
      },
      error: () => alert('Delete failed')
    });
}
  // 🔥 CONNECTED TO BACKEND
  loadStudents() {
    this.http.get<any[]>('http://localhost:3000/students')
      .subscribe(data => this.students = data);
  }
}
