const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// PostgreSQL connection
const pool = new Pool({
  user: '23510032',        // replace with your DB user
  host: 'localhost',
  database: 'DB23510032',    // replace with your DB name
  password: 'namrata32',   // replace with your password
  port: 5432
});

// Add new student
app.post('/students', async (req, res) => {
  const { roll, name, dept } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO student (roll, name, dept) VALUES ($1, $2, $3) RETURNING *',
      [roll, name, dept]
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
});

app.get('/students', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM student ORDER BY roll');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

app.delete('/students/:roll', async (req, res) => {
  const { roll } = req.params;

  try {
    await pool.query(
      'DELETE FROM student WHERE roll = $1',
      [roll]
    );
    res.send({ message: 'Student deleted' });
  } catch (err) {
    res.status(500).send(err);
  }
});

app.put('/students/:roll', async (req, res) => {
  const { roll } = req.params;
  const { name, dept } = req.body;

  try {
    await pool.query(
      'UPDATE student SET name=$1, dept=$2 WHERE roll=$3',
      [name, dept, roll]
    );
    res.send({ message: 'Student updated' });
  } catch (err) {
    res.status(500).send(err);
  }
});


app.listen(3000, () => console.log('Server running on port 3000'));
